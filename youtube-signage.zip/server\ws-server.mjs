import { createServer } from 'http';
import { WebSocketServer } from 'ws';

const PORT = process.env.WS_PORT || 5174;
const clients = new Set();
let playerState = {};

const server = createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/plain' });
  res.end('WS Remote Control Server');
});

const wss = new WebSocketServer({ server });

wss.on('connection', (ws) => {
  clients.add(ws);

  // Send current state to new client
  if (Object.keys(playerState).length > 0) {
    ws.send(JSON.stringify({ type: 'state', ...playerState }));
  }

  ws.send(JSON.stringify({ type: 'clients', count: clients.size }));

  ws.on('message', (raw) => {
    try {
      const msg = JSON.parse(raw);
      if (msg.type === 'state') {
        playerState = msg;
        broadcast(msg, ws);
      } else if (msg.type === 'cmd') {
        broadcast(raw.toString(), ws);
      } else if (msg.type === 'pong') {
        // keepalive response
      }
    } catch { }
  });

  ws.on('close', () => {
    clients.delete(ws);
    broadcast(JSON.stringify({ type: 'clients', count: clients.size }));
  });

  ws.on('error', () => clients.delete(ws));
});

function broadcast(data, sender) {
  const msg = typeof data === 'string' ? data : JSON.stringify(data);
  for (const client of clients) {
    if (client !== sender && client.readyState === 1) {
      client.send(msg);
    }
  }
}

// Ping clients every 30s
setInterval(() => {
  for (const client of clients) {
    if (client.readyState === 1) {
      client.send(JSON.stringify({ type: 'ping' }));
    }
  }
}, 30000);

server.listen(PORT, () => {
  console.log(`WS Remote Control server running on port ${PORT}`);
});
