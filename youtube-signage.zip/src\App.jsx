import { useEffect, useState } from 'react';
import VideoPlayer from './components/VideoPlayer';
import RemotePage from './pages/RemotePage';

function getRoute() {
  const hash = window.location.hash.replace(/^#\//, '');
  return hash || '/';
}

export default function App() {
  const [route, setRoute] = useState(getRoute);

  useEffect(() => {
    const handler = () => setRoute(getRoute());
    window.addEventListener('hashchange', handler);
    return () => window.removeEventListener('hashchange', handler);
  }, []);

  if (route === 'remote') return <RemotePage />;
  return <VideoPlayer />;
}
