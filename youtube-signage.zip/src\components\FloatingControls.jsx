import { useState, useEffect, useCallback, useRef } from 'react';
import {
  Maximize2, Minimize2, Play, Pause, SkipBack, SkipForward,
  RotateCcw, VolumeX, Volume2, Eye, EyeOff, Info, ChevronRight,
} from 'lucide-react';

const BTN_CLASS = 'p-2.5 rounded-lg hover:bg-white/10 transition-colors duration-200 text-white/80 hover:text-white disabled:opacity-30 disabled:pointer-events-none';

export default function FloatingControls({
  playing, muted, currentVideo, totalVideos, duration, progress,
  onTogglePlay, onPrev, onNext, onRestart, onToggleMute,
  onToggleFullscreen, onExitFullscreen, isFullscreen,
  config, onConfigChange,
  formatTime,
}) {
  const [visible, setVisible] = useState(true);
  const [minimized, setMinimized] = useState(false);
  const [showInfo, setShowInfo] = useState(config.showInfo !== false);
  const [showTitle, setShowTitle] = useState(config.showTitle !== false);
  const [controlsOn, setControlsOn] = useState(config.showControls !== false);
  const hideTimer = useRef(null);
  const panelRef = useRef(null);

  // --- Auto-hide on mouse inactivity ---
  const resetTimer = useCallback(() => {
    setVisible(true);
    clearTimeout(hideTimer.current);
    if (controlsOn && !minimized) {
      hideTimer.current = setTimeout(() => setVisible(false), config.hideControlsDelay || 3000);
    }
  }, [controlsOn, minimized, config.hideControlsDelay]);

  useEffect(() => {
    const handler = () => resetTimer();
    window.addEventListener('mousemove', handler);
    window.addEventListener('touchstart', handler);
    return () => {
      window.removeEventListener('mousemove', handler);
      window.removeEventListener('touchstart', handler);
      clearTimeout(hideTimer.current);
    };
  }, [resetTimer]);

  useEffect(() => {
    resetTimer();
  }, [controlsOn, minimized]);

  const toggleControls = () => {
    const next = !controlsOn;
    setControlsOn(next);
    onConfigChange?.({ showControls: next });
    if (!next) setVisible(false);
    else resetTimer();
  };

  const toggleShowInfo = () => {
    const next = !showInfo;
    setShowInfo(next);
    onConfigChange?.({ showInfo: next });
  };

  const toggleShowTitle = () => {
    const next = !showTitle;
    setShowTitle(next);
    onConfigChange?.({ showTitle: next });
  };

  if (!controlsOn) {
    return (
      <button onClick={toggleControls} className="fixed bottom-4 right-4 z-50 glass p-2.5 rounded-full text-white/60 hover:text-white transition-colors">
        <Eye size={18} />
      </button>
    );
  }

  if (minimized) {
    return (
      <button
        onClick={() => { setMinimized(false); resetTimer(); }}
        className="fixed right-3 top-1/2 -translate-y-1/2 z-50 glass p-2.5 rounded-full text-white/60 hover:text-white transition-all hover:scale-110"
      >
        <ChevronRight size={18} />
      </button>
    );
  }

  return (
    <div
      ref={panelRef}
      className={`fixed right-0 top-0 h-full z-40 flex flex-col items-center justify-center transition-opacity duration-500 ${visible ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
    >
      <div className="glass rounded-l-2xl py-4 px-2 flex flex-col items-center gap-1 mx-2 my-4 max-h-[90vh] overflow-y-auto">

        {/* Video info */}
        {showInfo && (
          <div className="text-white/60 text-[10px] text-center mb-2 px-1 leading-tight">
            <div className="font-semibold text-white/80 text-xs">{currentVideo + 1} / {totalVideos}</div>
            {showTitle && totalVideos > 0 && (
              <div className="mt-0.5 text-[9px] text-white/40">Video {currentVideo + 1}</div>
            )}
          </div>
        )}

        {/* Progress bar */}
        {showInfo && (
          <div className="w-20 h-1 bg-white/10 rounded-full mb-2 overflow-hidden">
            <div
              className="h-full bg-white/60 rounded-full transition-all duration-300"
              style={{ width: duration > 0 ? `${(progress / duration) * 100}%` : '0%' }}
            />
          </div>
        )}

        {showInfo && (
          <div className="text-[10px] text-white/40 mb-2 font-mono">
            {formatTime(progress)} / {formatTime(duration)}
          </div>
        )}

        {/* Separator */}
        <div className="w-8 h-px bg-white/10 mb-2" />

        {/* Control buttons */}
        <button onClick={onTogglePlay} className={BTN_CLASS} title="Play / Pause">
          {playing ? <Pause size={16} /> : <Play size={16} />}
        </button>

        <button onClick={onPrev} className={BTN_CLASS} title="Anterior">
          <SkipBack size={16} />
        </button>

        <button onClick={onNext} className={BTN_CLASS} title="Siguiente">
          <SkipForward size={16} />
        </button>

        <button onClick={onRestart} className={BTN_CLASS} title="Reiniciar">
          <RotateCcw size={16} />
        </button>

        <button onClick={onToggleMute} className={BTN_CLASS} title="Silenciar">
          {muted ? <VolumeX size={16} /> : <Volume2 size={16} />}
        </button>

        <div className="w-8 h-px bg-white/10 my-1" />

        <button onClick={onToggleFullscreen} className={BTN_CLASS} title="Pantalla completa">
          <Maximize2 size={16} />
        </button>

        {isFullscreen && (
          <button onClick={onExitFullscreen} className={BTN_CLASS} title="Salir de pantalla completa">
            <Minimize2 size={16} />
          </button>
        )}

        <div className="w-8 h-px bg-white/10 my-1" />

        <button onClick={toggleShowTitle} className={`${BTN_CLASS} ${showTitle ? 'text-white' : 'text-white/30'}`} title="Mostrar título">
          <Info size={16} />
        </button>

        <button onClick={toggleShowInfo} className={`${BTN_CLASS} ${showInfo ? 'text-white' : 'text-white/30'}`} title="Mostrar información">
          <Eye size={16} />
        </button>

        <button onClick={toggleControls} className={BTN_CLASS} title="Ocultar controles">
          <EyeOff size={16} />
        </button>

        {/* Minimize */}
        <div className="w-8 h-px bg-white/10 my-1" />
        <button onClick={() => setMinimized(true)} className="p-2 rounded-lg hover:bg-white/10 text-white/40 hover:text-white/60 transition-colors text-[10px] font-semibold">
          &gt;
        </button>
      </div>
    </div>
  );
}
