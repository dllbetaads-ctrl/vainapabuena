import { useMemo } from 'react';

const POSITIONS = {
  'top-left': { top: 0, left: 0 },
  'top-right': { top: 0, right: 0 },
  'bottom-left': { bottom: 0, left: 0 },
  'bottom-right': { bottom: 0, right: 0 },
  center: { top: '50%', left: '50%', transform: 'translate(-50%, -50%)' },
};

export default function LogoOverlay({ config }) {
  const { logo, logoSize, logoPosition, logoOpacity, logoMargin, overlay, overlayText, overlayEnabled } = config;

  const style = useMemo(() => {
    const pos = POSITIONS[logoPosition] || POSITIONS['bottom-right'];
    return {
      ...pos,
      margin: typeof logoMargin === 'number' ? `${logoMargin}px` : logoMargin,
      opacity: (logoOpacity ?? 80) / 100,
      width: logoSize ? `${logoSize}px` : undefined,
      height: logoSize ? `${logoSize}px` : undefined,
    };
  }, [logoPosition, logoMargin, logoOpacity, logoSize]);

  if (!logo && !overlayEnabled) return null;

  return (
    <>
      {logo && (
        <img
          src={logo}
          alt="logo"
          className="absolute z-30 object-contain pointer-events-none select-none"
          style={style}
        />
      )}

      {overlayEnabled && (
        <div className="absolute inset-0 z-20 pointer-events-none select-none">
          {overlay && (
            <img
              src={overlay}
              alt="overlay"
              className="w-full h-full object-cover opacity-30"
            />
          )}
          {overlayText && (
            <div className="absolute bottom-8 left-1/2 -translate-x-1/2 text-white text-lg md:text-xl font-semibold text-center px-6 py-3 rounded-lg glass max-w-[90%]">
              {overlayText}
            </div>
          )}
        </div>
      )}
    </>
  );
}
