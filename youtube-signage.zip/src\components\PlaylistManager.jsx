import { useState, useCallback } from 'react';
import { Plus, Trash2, ListMusic, X } from 'lucide-react';

export default function PlaylistManager({ videoIds, currentVideo, onAddVideos, onRemoveVideo, onLoadVideo, totalVideos }) {
  const [show, setShow] = useState(false);
  const [links, setLinks] = useState('');

  const handleAdd = useCallback(() => {
    const urls = links.split('\n').map((l) => l.trim()).filter(Boolean);
    if (urls.length === 0) return;
    onAddVideos(urls);
    setLinks('');
  }, [links, onAddVideos]);

  const handleKeyDown = useCallback((e) => {
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
      handleAdd();
    }
  }, [handleAdd]);

  return (
    <>
      <button
        onClick={() => setShow(true)}
        className="fixed top-4 right-20 z-30 glass p-2.5 rounded-full text-white/50 hover:text-white transition-all hover:scale-110"
        title="Gestionar playlist"
      >
        <ListMusic size={18} />
      </button>

      {show && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm">
          <div
            className="glass rounded-2xl w-full max-w-lg max-h-[85vh] mx-4 flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-white/10">
              <h2 className="text-white font-semibold text-lg">Playlist ({totalVideos} videos)</h2>
              <button onClick={() => setShow(false)} className="p-1.5 rounded-lg hover:bg-white/10 text-white/50 hover:text-white">
                <X size={18} />
              </button>
            </div>

            {/* Video list */}
            <div className="flex-1 overflow-y-auto p-3 space-y-1.5 min-h-0">
              {videoIds.length === 0 && (
                <p className="text-white/30 text-sm text-center py-8">Agrega videos usando el campo de abajo</p>
              )}
              {videoIds.map((id, i) => (
                <div
                  key={`${id}-${i}`}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg cursor-pointer transition-colors text-sm ${
                    i === currentVideo
                      ? 'bg-white/15 text-white'
                      : 'text-white/60 hover:bg-white/5 hover:text-white/80'
                  }`}
                  onClick={() => { onLoadVideo(i); setShow(false); }}
                >
                  <span className="text-[10px] text-white/30 w-5 text-right font-mono">{i + 1}</span>
                  <span className="flex-1 truncate">{id}</span>
                  {i === currentVideo && <span className="text-[9px] text-emerald-400 font-semibold">ACTUAL</span>}
                  <button
                    onClick={(e) => { e.stopPropagation(); onRemoveVideo(i); }}
                    className="p-1 rounded hover:bg-red-500/20 text-white/30 hover:text-red-400 opacity-0 hover:opacity-100 transition-all"
                  >
                    <Trash2 size={12} />
                  </button>
                </div>
              ))}
            </div>

            {/* Add links */}
            <div className="p-4 border-t border-white/10 space-y-2">
              <textarea
                value={links}
                onChange={(e) => setLinks(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Pega enlaces de YouTube aquí&#10;uno por línea&#10;Ctrl+Enter para agregar"
                rows={4}
                className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-white/20 focus:outline-none focus:border-white/30 resize-none transition-colors"
              />
              <div className="flex justify-between items-center">
                <span className="text-[10px] text-white/30">Ej: https://youtube.com/watch?v=...</span>
                <button
                  onClick={handleAdd}
                  disabled={!links.trim()}
                  className="flex items-center gap-1.5 px-4 py-2 bg-white/10 hover:bg-white/20 disabled:opacity-30 disabled:pointer-events-none rounded-lg text-white text-sm transition-colors"
                >
                  <Plus size={14} /> Agregar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
