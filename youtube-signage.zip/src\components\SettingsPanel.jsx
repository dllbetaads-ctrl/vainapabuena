import { useState, useRef, useCallback } from 'react';
import { X, Upload, RotateCcw } from 'lucide-react';

export default function SettingsPanel({ config, onConfigChange, onClose, onLoadPlaylist }) {
  const [url, setUrl] = useState(config.playlistUrl || '');
  const logoInput = useRef(null);
  const overlayInput = useRef(null);
  const fileInputRef = useRef(null);

  const update = useCallback((patch) => {
    onConfigChange(patch);
  }, [onConfigChange]);

  const handleLoad = () => {
    if (!url.trim()) return;
    update({ playlistUrl: url.trim() });
    onLoadPlaylist(url.trim());
  };

  const handleLogo = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => update({ logo: ev.target.result });
    reader.readAsDataURL(file);
  };

  const handleOverlay = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => update({ overlay: ev.target.result });
    reader.readAsDataURL(file);
  };

  const removeLogo = () => update({ logo: null });
  const removeOverlay = () => update({ overlay: null });

  const resetAll = () => {
    onConfigChange('RESET');
    setUrl('');
  };

  const INPUT_LABEL = 'block text-xs font-medium text-white/60 mb-1';
  const INPUT = 'w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-white/20 focus:outline-none focus:border-white/30 transition-colors';
  const SELECT = 'w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-white/30 transition-colors';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm" onClick={onClose}>
      <div
        className="glass rounded-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto mx-4 p-6 md:p-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-white text-xl font-semibold">Configuración</h2>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-white/10 text-white/60 hover:text-white transition-colors">
            <X size={20} />
          </button>
        </div>

        <div className="settings-grid">

          {/* Playlist URL */}
          <div className="md:col-span-2">
            <label className={INPUT_LABEL}>URL de Playlist de YouTube</label>
            <div className="flex gap-2">
              <input
                type="text"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleLoad()}
                placeholder="https://youtube.com/playlist?list=..."
                className={`${INPUT} flex-1`}
              />
              <button onClick={handleLoad} className="px-4 py-2 bg-white/10 hover:bg-white/20 rounded-lg text-white text-sm font-medium transition-colors whitespace-nowrap">
                Cargar
              </button>
            </div>
          </div>

          {/* Logo */}
          <div>
            <label className={INPUT_LABEL}>Logo personalizado</label>
            <div className="flex items-center gap-3">
              <input ref={logoInput} type="file" accept="image/*" onChange={handleLogo} hidden />
              <button onClick={() => logoInput.current?.click()} className="flex items-center gap-2 px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white/70 text-sm hover:bg-white/10 transition-colors">
                <Upload size={14} /> Subir
              </button>
              {config.logo && (
                <button onClick={removeLogo} className="text-xs text-red-400 hover:text-red-300">Eliminar</button>
              )}
            </div>
            {config.logo && (
              <img src={config.logo} alt="preview" className="mt-2 h-10 w-auto object-contain rounded" />
            )}
          </div>

          {/* Overlay */}
          <div>
            <label className={INPUT_LABEL}>Overlay / Marca de agua</label>
            <div className="flex items-center gap-3">
              <input ref={overlayInput} type="file" accept="image/*" onChange={handleOverlay} hidden />
              <button onClick={() => overlayInput.current?.click()} className="flex items-center gap-2 px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white/70 text-sm hover:bg-white/10 transition-colors">
                <Upload size={14} /> Subir
              </button>
              {config.overlay && (
                <button onClick={removeOverlay} className="text-xs text-red-400 hover:text-red-300">Eliminar</button>
              )}
            </div>
            {config.overlay && (
              <img src={config.overlay} alt="preview" className="mt-2 h-10 w-auto object-contain rounded" />
            )}
          </div>

          {/* Logo position */}
          <div>
            <label className={INPUT_LABEL}>Posición del logo</label>
            <select
              value={config.logoPosition}
              onChange={(e) => update({ logoPosition: e.target.value })}
              className={SELECT}
            >
              <option value="top-left">Superior izquierda</option>
              <option value="top-right">Superior derecha</option>
              <option value="bottom-left">Inferior izquierda</option>
              <option value="bottom-right">Inferior derecha</option>
              <option value="center">Centro</option>
            </select>
          </div>

          {/* Logo size */}
          <div>
            <label className={INPUT_LABEL}>Tamaño del logo: {config.logoSize}px</label>
            <input
              type="range" min="20" max="300"
              value={config.logoSize}
              onChange={(e) => update({ logoSize: Number(e.target.value) })}
              className="w-full"
            />
          </div>

          {/* Logo opacity */}
          <div>
            <label className={INPUT_LABEL}>Opacidad del logo: {config.logoOpacity}%</label>
            <input
              type="range" min="10" max="100"
              value={config.logoOpacity}
              onChange={(e) => update({ logoOpacity: Number(e.target.value) })}
              className="w-full"
            />
          </div>

          {/* Logo margin */}
          <div>
            <label className={INPUT_LABEL}>Margen del logo: {config.logoMargin}px</label>
            <input
              type="range" min="0" max="100"
              value={config.logoMargin}
              onChange={(e) => update({ logoMargin: Number(e.target.value) })}
              className="w-full"
            />
          </div>

          {/* Overlay text */}
          <div className="md:col-span-2">
            <label className={INPUT_LABEL}>Texto del overlay</label>
            <input
              type="text"
              value={config.overlayText}
              onChange={(e) => update({ overlayText: e.target.value })}
              placeholder="Texto informativo..."
              className={INPUT}
            />
          </div>

          {/* Overlay enabled */}
          <div className="flex items-center gap-3">
            <input
              type="checkbox"
              id="overlayEnabled"
              checked={config.overlayEnabled}
              onChange={(e) => update({ overlayEnabled: e.target.checked })}
              className="w-4 h-4 accent-white/50"
            />
            <label htmlFor="overlayEnabled" className="text-sm text-white/70">Activar overlay</label>
          </div>

          <div className="md:col-span-2 grid grid-cols-2 gap-4">
            {/* Autoplay */}
            <div className="flex items-center gap-3">
              <input
                type="checkbox"
                id="autoplay"
                checked={config.autoplay}
                onChange={(e) => update({ autoplay: e.target.checked })}
                className="w-4 h-4 accent-white/50"
              />
              <label htmlFor="autoplay" className="text-sm text-white/70">Autoplay</label>
            </div>

            {/* Loop */}
            <div className="flex items-center gap-3">
              <input
                type="checkbox"
                id="loop"
                checked={config.loop}
                onChange={(e) => update({ loop: e.target.checked })}
                className="w-4 h-4 accent-white/50"
              />
              <label htmlFor="loop" className="text-sm text-white/70">Loop / Repetir</label>
            </div>

            {/* Show info */}
            <div className="flex items-center gap-3">
              <input
                type="checkbox"
                id="showTitle"
                checked={config.showTitle !== false}
                onChange={(e) => update({ showTitle: e.target.checked })}
                className="w-4 h-4 accent-white/50"
              />
              <label htmlFor="showTitle" className="text-sm text-white/70">Mostrar títulos</label>
            </div>

            {/* Show controls */}
            <div className="flex items-center gap-3">
              <input
                type="checkbox"
                id="showControls"
                checked={config.showControls !== false}
                onChange={(e) => update({ showControls: e.target.checked })}
                className="w-4 h-4 accent-white/50"
              />
              <label htmlFor="showControls" className="text-sm text-white/70">Mostrar controles</label>
            </div>

            {/* Hide delay */}
            <div className="md:col-span-2">
              <label className={INPUT_LABEL}>Tiempo para ocultar controles: {config.hideControlsDelay}ms</label>
              <input
                type="range" min="1000" max="15000" step="500"
                value={config.hideControlsDelay}
                onChange={(e) => update({ hideControlsDelay: Number(e.target.value) })}
                className="w-full"
              />
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center justify-between mt-8 pt-4 border-t border-white/10">
          <button onClick={resetAll} className="flex items-center gap-2 px-4 py-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-lg text-sm transition-colors">
            <RotateCcw size={14} /> Restablecer
          </button>
          <button onClick={onClose} className="px-6 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg text-sm font-medium transition-colors">
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
}
