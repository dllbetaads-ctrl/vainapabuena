import { useRef, useEffect, useState, useCallback } from 'react';
import useYouTubePlayer from '../hooks/useYouTubePlayer';
import useFullscreen from '../hooks/useFullscreen';
import useRemoteControl from '../hooks/useRemoteControl';
import FloatingControls from './FloatingControls';
import LogoOverlay from './LogoOverlay';
import SettingsPanel from './SettingsPanel';
import PlaylistManager from './PlaylistManager';
import { loadConfig, saveConfig, resetConfig } from '../utils/storage';
import { Settings, AlertCircle, Smartphone } from 'lucide-react';

export default function VideoPlayer() {
  const containerRef = useRef(null);
  const [config, setConfig] = useState(loadConfig);
  const [showSettings, setShowSettings] = useState(false);
  const [showQr, setShowQr] = useState(false);
  const [initialized, setInitialized] = useState(false);

  const player = useYouTubePlayer(containerRef);
  const fs = useFullscreen();

  // --- Remote control command handler ---
  const handleRemoteCommand = useCallback((action, payload) => {
    switch (action) {
      case 'play': player.play(); break;
      case 'pause': player.pause(); break;
      case 'next': player.next(); break;
      case 'prev': player.prev(); break;
      case 'restart': player.restart(); break;
      case 'mute': player.toggleMute(); break;
      case 'fullscreen': fs.enter(); break;
      case 'load': player.loadVideo(payload); break;
    }
  }, [player, fs]);

  const remote = useRemoteControl(handleRemoteCommand);

  // --- Send state to remote clients ---
  useEffect(() => {
    const interval = setInterval(() => {
      if (remote.connected) {
        remote.sendState({
          playing: player.playing,
          muted: player.muted,
          currentVideo: player.currentVideo,
          totalVideos: player.totalVideos,
          duration: player.duration,
          progress: player.progress,
          videoIds: player.videoIds,
        });
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [remote.connected, player.playing, player.muted, player.currentVideo,
      player.totalVideos, player.duration, player.progress, player.videoIds]);

  // --- Load saved videos on mount ---
  useEffect(() => {
    if (!initialized && config.videoUrls && config.videoUrls.length > 0) {
      player.addVideos(config.videoUrls);
      setInitialized(true);
    } else if (!initialized) {
      setInitialized(true);
    }
  }, [config.videoUrls]);

  // --- Sync autoplay/loop ---
  useEffect(() => {
    player.setAutoplay(config.autoplay);
  }, [config.autoplay]);

  // --- Config change handler ---
  const handleConfigChange = useCallback((patch) => {
    if (patch === 'RESET') {
      const def = resetConfig();
      setConfig(def);
      player.setAutoplay(def.autoplay);
      return;
    }
    setConfig((prev) => {
      const next = { ...prev, ...patch };
      saveConfig(next);
      return next;
    });
  }, [player]);

  // --- Add videos from PlaylistManager ---
  const handleAddVideos = useCallback((urls) => {
    const result = player.addVideos(urls);
    if (result.success) {
      setConfig((prev) => {
        const next = { ...prev, videoUrls: [...(prev.videoUrls || []), ...urls] };
        saveConfig(next);
        return next;
      });
    }
  }, [player]);

  const handleRemoveVideo = useCallback((index) => {
    const url = config.videoUrls?.[index];
    player.removeVideo(index);
    if (url) {
      setConfig((prev) => {
        const next = {
          ...prev,
          videoUrls: prev.videoUrls.filter((_, i) => i !== index),
        };
        saveConfig(next);
        return next;
      });
    }
  }, [player, config.videoUrls]);

  const handleLoadPlaylist = useCallback((url) => {
    player.loadPlaylist(url);
  }, [player]);

  // --- QR code remote URL ---
  const remoteUrl = `${window.location.protocol}//${window.location.hostname}${window.location.port ? ':' + window.location.port : ''}${window.location.pathname}#/remote`;

  return (
    <div className="relative w-full h-full bg-black overflow-hidden select-none">
      {/* Video container */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="relative w-full h-full">
          <div ref={containerRef} className="w-full h-full" />
          <LogoOverlay config={config} />
          <div className="absolute inset-0 pointer-events-none bg-gradient-to-t from-black/10 via-transparent to-black/10" />
        </div>
      </div>

      {/* Error overlay */}
      {player.error && (
        <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/80">
          <div className="glass rounded-2xl p-8 max-w-md text-center">
            <AlertCircle className="mx-auto mb-4 text-red-400" size={40} />
            <p className="text-white/80 text-sm mb-2">{player.error}</p>
            <p className="text-white/40 text-xs mb-4">Verifica los enlaces e intenta de nuevo</p>
            <button onClick={() => setShowSettings(true)} className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg text-sm transition-colors">
              Abrir configuración
            </button>
          </div>
        </div>
      )}

      {/* Floating controls */}
      <FloatingControls
        playing={player.playing}
        muted={player.muted}
        currentVideo={player.currentVideo}
        totalVideos={player.totalVideos}
        duration={player.duration}
        progress={player.progress}
        onTogglePlay={player.togglePlay}
        onPrev={player.prev}
        onNext={player.next}
        onRestart={player.restart}
        onToggleMute={player.toggleMute}
        onToggleFullscreen={fs.enter}
        onExitFullscreen={fs.exit}
        isFullscreen={fs.isFullscreen}
        config={config}
        onConfigChange={handleConfigChange}
        formatTime={player.formatTime}
      />

      {/* Playlist manager button */}
      <PlaylistManager
        videoIds={player.videoIds}
        currentVideo={player.currentVideo}
        totalVideos={player.totalVideos}
        onAddVideos={handleAddVideos}
        onRemoveVideo={handleRemoveVideo}
        onLoadVideo={player.loadVideo}
      />

      {/* Remote control button */}
      <button
        onClick={() => setShowQr(!showQr)}
        className="fixed top-4 right-36 z-30 glass p-2.5 rounded-full text-white/50 hover:text-white transition-all hover:scale-110"
        title="Control remoto"
      >
        <Smartphone size={18} />
      </button>

      {/* QR popup */}
      {showQr && (
        <div className="fixed top-16 right-4 z-40 glass rounded-2xl p-4 w-48 text-center" onClick={() => setShowQr(false)}>
          <div className="text-white/80 text-xs font-medium mb-2">Control Remoto</div>
          <div className="bg-white p-3 rounded-xl mb-2 inline-block">
            <img
              src={`https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=${encodeURIComponent(remoteUrl)}`}
              alt="QR"
              className="w-28 h-28"
              crossOrigin="anonymous"
            />
          </div>
          <div className="text-[10px] text-white/40 break-all">{remoteUrl}</div>
          <div className="text-[9px] text-emerald-400/60 mt-1">
            {remote.connected ? `${remote.clients} dispositivo(s) conectado(s)` : 'Servidor WebSocket no disponible'}
          </div>
        </div>
      )}

      {/* Settings toggle */}
      <button
        onClick={() => setShowSettings(true)}
        className="fixed top-4 left-4 z-30 glass p-2.5 rounded-full text-white/50 hover:text-white transition-all hover:scale-110"
        title="Configuración"
      >
        <Settings size={18} />
      </button>

      {/* Status bar */}
      {player.totalVideos > 0 && config.showInfo !== false && (
        <div className="fixed bottom-4 left-4 z-30 glass rounded-lg px-3 py-1.5 text-white/50 text-[10px] font-mono">
          {player.currentVideo + 1} / {player.totalVideos}
        </div>
      )}

      {/* Playlist title */}
      {player.playlistTitle && config.showInfo !== false && (
        <div className="fixed top-4 left-16 z-30 glass rounded-lg px-3 py-1.5 text-white/50 text-[11px] truncate max-w-[300px]">
          {player.playlistTitle}
        </div>
      )}

      {/* Settings modal */}
      {showSettings && (
        <SettingsPanel
          config={config}
          onConfigChange={handleConfigChange}
          onClose={() => setShowSettings(false)}
          onLoadPlaylist={handleLoadPlaylist}
        />
      )}
    </div>
  );
}
