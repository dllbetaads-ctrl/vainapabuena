import { useState, useEffect, useRef, useCallback } from 'react';

const WS_URL = import.meta.env.VITE_WS_URL || `ws://${window.location.hostname}:5174`;

export default function useRemoteControl(onCommand) {
  const [connected, setConnected] = useState(false);
  const [clients, setClients] = useState(0);
  const ws = useRef(null);
  const reconnectTimer = useRef(null);

  useEffect(() => {
    function connect() {
      try {
        const socket = new WebSocket(WS_URL);
        socket.onopen = () => {
          setConnected(true);
          ws.current = socket;
        };
        socket.onmessage = (e) => {
          try {
            const msg = JSON.parse(e.data);
            if (msg.type === 'ping') {
              socket.send(JSON.stringify({ type: 'pong' }));
              return;
            }
            if (msg.type === 'clients') {
              setClients(msg.count || 0);
              return;
            }
            if (onCommand && msg.type === 'cmd') {
              onCommand(msg.action, msg.payload);
            }
          } catch { }
        };
        socket.onclose = () => {
          setConnected(false);
          ws.current = null;
          reconnectTimer.current = setTimeout(connect, 3000);
        };
        socket.onerror = () => socket.close();
      } catch { }
    }

    connect();
    return () => {
      clearTimeout(reconnectTimer.current);
      if (ws.current) ws.current.close();
    };
  }, []);

  const sendState = useCallback((state) => {
    if (ws.current && ws.current.readyState === WebSocket.OPEN) {
      ws.current.send(JSON.stringify({ type: 'state', ...state }));
    }
  }, []);

  return { connected, clients, sendState };
}
