import { useState, useRef, useCallback, useEffect } from 'react';

const API_URL = 'https://www.youtube.com/iframe_api';

let apiReady = false;
const queue = [];

window.onYouTubeIframeAPIReady = () => {
  apiReady = true;
  queue.forEach((fn) => fn());
  queue.length = 0;
};

function ensureApi(cb) {
  if (apiReady) return cb();
  queue.push(cb);
  if (!document.querySelector('#youtube-api-script')) {
    const tag = document.createElement('script');
    tag.id = 'youtube-api-script';
    tag.src = API_URL;
    document.head.appendChild(tag);
  }
}

function extractVideoId(url) {
  const u = url.trim();
  if (!u) return null;
  try {
    const parsed = new URL(u);
    if (parsed.hostname.includes('youtube.com') || parsed.hostname.includes('youtu.be')) {
      if (parsed.searchParams.has('v')) return parsed.searchParams.get('v');
      const path = parsed.pathname.replace(/^\//, '');
      const parts = path.split('/');
      if (parsed.hostname.includes('youtu.be') && parts[0]) return parts[0];
      if (parts[0] === 'embed' && parts[1]) return parts[1];
      if (parts[0] === 'shorts' && parts[1]) return parts[1];
    }
  } catch { /* invalid URL */ }
  return null;
}

export default function useYouTubePlayer(containerRef) {
  const [player, setPlayer] = useState(null);
  const [ready, setReady] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(false);
  const [currentVideo, setCurrentVideo] = useState(0);
  const [totalVideos, setTotalVideos] = useState(0);
  const [duration, setDuration] = useState(0);
  const [progress, setProgress] = useState(0);
  const [videoIds, setVideoIds] = useState([]);
  const [playlistTitle, setPlaylistTitle] = useState('');
  const [error, setError] = useState(null);
  const playerRef = useRef(null);
  const progressInterval = useRef(null);
  const autoplayRef = useRef(true);
  const videoIdsRef = useRef([]);

  const startProgress = useCallback(() => {
    clearInterval(progressInterval.current);
    progressInterval.current = setInterval(() => {
      if (playerRef.current && playerRef.current.getCurrentTime !== undefined) {
        try {
          const t = playerRef.current.getCurrentTime();
          const d = playerRef.current.getDuration();
          setProgress(t);
          if (d) setDuration(d);
        } catch { }
      }
    }, 500);
  }, []);

  // --- Add a single video URL ---
  const addVideo = useCallback((url) => {
    const id = extractVideoId(url);
    if (!id) return { success: false, error: 'URL de YouTube no válida' };
    setVideoIds((prev) => {
      const next = [...prev, id];
      videoIdsRef.current = next;
      setTotalVideos(next.length);
      if (next.length === 1 && playerRef.current) {
        playerRef.current.cueVideoById(id);
        setCurrentVideo(0);
      }
      return next;
    });
    return { success: true, id };
  }, []);

  // --- Add multiple video URLs ---
  const addVideos = useCallback((urls) => {
    const ids = [];
    const errors = [];
    urls.forEach((url) => {
      const id = extractVideoId(url);
      if (id) ids.push(id);
      else errors.push(url);
    });
    if (ids.length === 0) return { success: false, error: 'Ninguna URL válida' };
    setVideoIds((prev) => {
      const next = [...prev, ...ids];
      videoIdsRef.current = next;
      setTotalVideos(next.length);
      if (next.length === ids.length && playerRef.current) {
        playerRef.current.cueVideoById(ids[0]);
        setCurrentVideo(0);
      }
      return next;
    });
    return { success: true, added: ids.length, errors: errors.length };
  }, []);

  // --- Set video list directly ---
  const setVideoList = useCallback((ids) => {
    setError(null);
    setCurrentVideo(0);
    videoIdsRef.current = ids;
    setVideoIds(ids);
    setTotalVideos(ids.length);
    if (ids.length > 0 && playerRef.current) {
      playerRef.current.cueVideoById(ids[0]);
    }
  }, []);

  // --- Remove video from list ---
  const removeVideo = useCallback((index) => {
    setVideoIds((prev) => {
      const next = prev.filter((_, i) => i !== index);
      videoIdsRef.current = next;
      setTotalVideos(next.length);
      if (next.length === 0) {
        if (playerRef.current) playerRef.current.stopVideo();
        setCurrentVideo(0);
      } else if (index <= currentVideo) {
        const newIdx = Math.max(0, currentVideo - 1);
        setCurrentVideo(newIdx);
        if (playerRef.current) playerRef.current.cueVideoById(next[newIdx]);
      }
      return next;
    });
  }, [currentVideo]);

  // --- Create player once videoIds are ready ---
  useEffect(() => {
    if (!containerRef.current || videoIds.length === 0 || playerRef.current) return;

    const container = containerRef.current;

    ensureApi(() => {
      const p = new YT.Player(container, {
        height: '100%',
        width: '100%',
        playerVars: {
          controls: 0,
          modestbranding: 1,
          rel: 0,
          iv_load_policy: 3,
          disablekb: 1,
          fs: 0,
          cc_load_policy: 0,
          autoplay: 0,
          playsinline: 1,
          origin: window.location.origin,
          enablejsapi: 1,
          widgetid: 1,
        },
        events: {
          onReady: () => {
            playerRef.current = p;
            setPlayer(p);
            setReady(true);
            setMuted(p.isMuted());
            if (videoIds.length > 0) {
              p.cueVideoById(videoIds[0]);
            }
          },
          onStateChange: (e) => {
            if (e.data === YT.PlayerState.PLAYING) {
              setPlaying(true);
              startProgress();
            } else if (e.data === YT.PlayerState.PAUSED) {
              setPlaying(false);
              clearInterval(progressInterval.current);
            } else if (e.data === YT.PlayerState.ENDED) {
              setPlaying(false);
              clearInterval(progressInterval.current);
              const ids = videoIdsRef.current;
              const nextIdx = currentVideo + 1;
              if (nextIdx < ids.length) {
                p.loadVideoById(ids[nextIdx]);
                setCurrentVideo(nextIdx);
              } else if (autoplayRef.current && ids.length > 0) {
                p.loadVideoById(ids[0]);
                setCurrentVideo(0);
              }
            } else if (e.data === YT.PlayerState.CUED) {
              setDuration(p.getDuration());
            }
          },
          onError: () => {
            setError('Error al reproducir video');
          },
        },
      });
    });

    return () => {
      clearInterval(progressInterval.current);
      if (playerRef.current) {
        try { playerRef.current.destroy(); } catch { }
        playerRef.current = null;
      }
    };
  }, [videoIds.length]);

  const playVideo = useCallback(() => { if (playerRef.current) playerRef.current.playVideo(); }, []);
  const pauseVideo = useCallback(() => { if (playerRef.current) playerRef.current.pauseVideo(); }, []);
  const togglePlay = useCallback(() => {
    if (playing) pauseVideo(); else playVideo();
  }, [playing, playVideo, pauseVideo]);

  const next = useCallback(() => {
    if (!playerRef.current) return;
    const ids = videoIdsRef.current;
    if (ids.length === 0) return;
    const idx = (currentVideo + 1) % ids.length;
    playerRef.current.loadVideoById(ids[idx]);
    setCurrentVideo(idx);
  }, [currentVideo]);

  const prev = useCallback(() => {
    if (!playerRef.current) return;
    const ids = videoIdsRef.current;
    if (ids.length === 0) return;
    const idx = (currentVideo - 1 + ids.length) % ids.length;
    playerRef.current.loadVideoById(ids[idx]);
    setCurrentVideo(idx);
  }, [currentVideo]);

  const restart = useCallback(() => {
    if (playerRef.current) {
      playerRef.current.seekTo(0, true);
      playerRef.current.playVideo();
    }
  }, []);

  const toggleMute = useCallback(() => {
    if (playerRef.current) {
      if (playerRef.current.isMuted()) {
        playerRef.current.unMute();
        setMuted(false);
      } else {
        playerRef.current.mute();
        setMuted(true);
      }
    }
  }, []);

  const setAutoplay = useCallback((val) => {
    autoplayRef.current = val;
  }, []);

  const seekTo = useCallback((seconds) => {
    if (playerRef.current) {
      playerRef.current.seekTo(seconds, true);
    }
  }, []);

  const loadVideo = useCallback((index) => {
    const ids = videoIdsRef.current;
    if (!playerRef.current || index < 0 || index >= ids.length) return;
    playerRef.current.loadVideoById(ids[index]);
    setCurrentVideo(index);
  }, []);

  const formatTime = useCallback((s) => {
    if (!s || !isFinite(s)) return '0:00';
    const m = Math.floor(s / 60);
    const sec = Math.floor(s % 60);
    return `${m}:${sec.toString().padStart(2, '0')}`;
  }, []);

  return {
    player,
    ready,
    playing,
    muted,
    currentVideo,
    totalVideos,
    duration,
    progress,
    videoIds,
    playlistTitle,
    error,
    play: playVideo,
    pause: pauseVideo,
    togglePlay,
    next,
    prev,
    restart,
    toggleMute,
    addVideo,
    addVideos,
    setVideoList,
    removeVideo,
    setAutoplay,
    seekTo,
    loadVideo,
    formatTime,
    setCurrentVideo,
  };
}
