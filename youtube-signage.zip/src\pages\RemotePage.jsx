import { useState, useEffect, useRef, useCallback } from 'react';
import { Play, Pause, SkipBack, SkipForward, RotateCcw, Volume2, VolumeX, Maximize2, Smartphone, Wifi, WifiOff } from 'lucide-react';

const WS_URL = import.meta.env.VITE_WS_URL || `ws://${window.location.hostname}:5174`;

const btn = 'p-4 rounded-xl bg-white/10 hover:bg-white/20 active:bg-white/30 transition-colors text-white disabled:opacity-30 disabled:pointer-events-none';

export default function RemotePage() {
  const [connected, setConnected] = useState(false);
  const [state, setState] = useState({
    playing: false,
    muted: false,
    currentVideo: 0,
    totalVideos: 0,
    duration: 0,
    progress: 0,
    videoIds: [],
  });
  const ws = useRef(null);

  useEffect(() => {
    function connect() {
      const socket = new WebSocket(WS_URL);
      socket.onopen = () => { setConnected(true); ws.current = socket; };
      socket.onmessage = (e) => {
        try {
          const msg = JSON.parse(e.data);
          if (msg.type === 'ping') { socket.send(JSON.stringify({ type: 'pong' })); return; }
          if (msg.type === 'state') setState(msg);
        } catch { }
      };
      socket.onclose = () => { setConnected(false); ws.current = null; setTimeout(connect, 3000); };
      socket.onerror = () => socket.close();
    }
    connect();
    return () => { if (ws.current) ws.current.close(); };
  }, []);

  const send = useCallback((action, payload) => {
    if (ws.current && ws.current.readyState === WebSocket.OPEN) {
      ws.current.send(JSON.stringify({ type: 'cmd', action, payload }));
    }
  }, []);

  const format = (s) => {
    if (!s || !isFinite(s)) return '0:00';
    return `${Math.floor(s / 60)}:${Math.floor(s % 60).toString().padStart(2, '0')}`;
  };

  const pct = state.duration > 0 ? (state.progress / state.duration) * 100 : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 text-white flex flex-col items-center justify-center p-6 select-none">

      {/* Status header */}
      <div className="flex items-center gap-2 mb-6">
        <Smartphone size={16} className="text-white/40" />
        <span className="text-xs text-white/40 font-mono">Control Remoto</span>
        {connected ? (
          <span className="flex items-center gap-1 text-[10px] text-emerald-400"><Wifi size={10} /> Conectado</span>
        ) : (
          <span className="flex items-center gap-1 text-[10px] text-red-400"><WifiOff size={10} /> Desconectado</span>
        )}
      </div>

      {/* Video info */}
      {state.totalVideos > 0 && (
        <div className="text-center mb-8">
          <div className="text-3xl font-bold mb-1">{state.currentVideo + 1} <span className="text-white/30 text-lg">/ {state.totalVideos}</span></div>
          <div className="text-sm text-white/50 font-mono">{format(state.progress)} / {format(state.duration)}</div>
          {/* Progress bar */}
          <div className="w-48 h-1.5 bg-white/10 rounded-full mt-3 mx-auto overflow-hidden">
            <div className="h-full bg-white/60 rounded-full transition-all duration-300" style={{ width: `${pct}%` }} />
          </div>
        </div>
      )}

      {state.totalVideos === 0 && (
        <div className="text-white/30 text-sm mb-8 text-center">
          Esperando videos...
        </div>
      )}

      {/* Main controls */}
      <div className="grid grid-cols-3 gap-4 mb-8">
        <button onClick={() => send('prev')} className={btn}><SkipBack size={24} /></button>
        <button onClick={() => send(state.playing ? 'pause' : 'play')} className={`${btn} scale-110 bg-white/15`}>
          {state.playing ? <Pause size={28} /> : <Play size={28} />}
        </button>
        <button onClick={() => send('next')} className={btn}><SkipForward size={24} /></button>
      </div>

      {/* Secondary controls */}
      <div className="grid grid-cols-3 gap-3">
        <button onClick={() => send('restart')} className="p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-colors text-white/60">
          <RotateCcw size={18} className="mx-auto" />
          <span className="block text-[9px] mt-1">Reiniciar</span>
        </button>
        <button onClick={() => send('mute')} className="p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-colors text-white/60">
          {state.muted ? <VolumeX size={18} className="mx-auto" /> : <Volume2 size={18} className="mx-auto" />}
          <span className="block text-[9px] mt-1">Silenciar</span>
        </button>
        <button onClick={() => send('fullscreen')} className="p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-colors text-white/60">
          <Maximize2 size={18} className="mx-auto" />
          <span className="block text-[9px] mt-1">Fullscreen</span>
        </button>
      </div>

      {/* Video list */}
      {state.videoIds && state.videoIds.length > 1 && (
        <div className="mt-8 w-full max-w-xs">
          <div className="text-[10px] text-white/30 mb-2 uppercase tracking-wider">Lista de videos</div>
          <div className="space-y-1 max-h-40 overflow-y-auto">
            {state.videoIds.map((id, i) => (
              <button
                key={i}
                onClick={() => send('load', i)}
                className={`w-full text-left px-3 py-1.5 rounded-lg text-xs transition-colors ${
                  i === state.currentVideo ? 'bg-white/15 text-white' : 'text-white/50 hover:bg-white/5'
                }`}
              >
                <span className="text-[9px] text-white/30 mr-2">{i + 1}</span>
                {id}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
