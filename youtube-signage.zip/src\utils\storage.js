const STORAGE_KEY = 'youtube-signage-config';

const DEFAULTS = {
  playlistUrl: '',
  logo: null,
  logoSize: 80,
  logoPosition: 'bottom-right',
  logoOpacity: 80,
  logoMargin: 20,
  overlay: null,
  overlayText: '',
  overlayEnabled: false,
  showInfo: true,
  showTitle: true,
  showControls: true,
  autoplay: true,
  loop: true,
  hideControlsDelay: 3000,
};

export function loadConfig() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { ...DEFAULTS };
    const parsed = JSON.parse(raw);
    return { ...DEFAULTS, ...parsed };
  } catch {
    return { ...DEFAULTS };
  }
}

export function saveConfig(config) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
  } catch {
    // Storage full or unavailable
  }
}

export function resetConfig() {
  localStorage.removeItem(STORAGE_KEY);
  return { ...DEFAULTS };
}
